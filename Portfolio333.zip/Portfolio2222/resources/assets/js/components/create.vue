<template>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Create Post</div>

                    <div class="panel-body">

                        <form v-on:submit="submitPost()" enctype="multipart/form-data">
                            <div class="form-group">
                                <input type="text" v-model="posts.title" placeholder="title" class="form-control">
                            </div>
                            <div class="form-group">
                                <textarea rows="5" cols="20" v-model="posts.description" placeholder="Description" class="form-control"></textarea>
                            </div>


                            <div class="form-group">

                                <select v-model="posts.student_id">
                                    <option v-for="student in students" v-bind:value="student.id" v-text="student.name"></option>

                                    <option v-for="v_area in locationlist" v-bind:value="v_area.id" v-text="v_area.name"></option>

                                </select>

                            </div>

                            <div id='example-3'>
                                <div v-for="cat in categories">

                                <input type="checkbox" v-bind:id="cat.id" v-bind:value="cat.id" v-model="checkedNames">
                                <label for="jack">{{cat.cat_name}}</label>

                                </div>


                                <!--<input type="checkbox" id="jack" value="1" v-model="checkedNames">-->
                                <!--<label for="jack">Jack</label>-->
                                <!--<input type="checkbox" id="john" value="2" v-model="checkedNames">-->
                                <!--<label for="john">John</label>-->
                                <!--<input type="checkbox" id="mike" value="3" v-model="checkedNames">-->
                                <!--<label for="mike">Mike</label>-->
                                <!--<br>-->
                                <span>Checked names: {{ checkedNames }}</span>




                            </div>



                            <div class="form-group">
                                <router-link to="/" class="btn btn-warning">Go to Back</router-link>
                                <button type="submit" class="btn btn-info">Create</button>
                            </div>


                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>

    export default {
        data:function() {
            return {
                posts:{
                    title:'',
                    description:'',
                    student_id:'',
                    status:'',
                    image:'',


                },
                checkedNames: [],
                students:[],
                categories:[],
                errors: [],
            }
        },


        // Fetches posts when the component is created.

        created(){
            this.fetchStudent();
            this.fetchCategory();
        },
        methods:{

            fetchStudent(){
                axios.get('http://localhost/Portfolio2222/public/stu').then(response=>{this.students=response.data.students});
            },

            fetchCategory(){
                axios.get('http://localhost/Portfolio2222/public/cat').then(response=>{this.categories=response.data.categories});
            },

            submitPost() {
                axios.post('http://localhost/Portfolio2222/public/posts3',


                    {posts:this.posts,checkedNames:this.checkedNames}

                ).then(response => {
                        console.log(response)
                        console.log(this.checkedNames);

//          this.$router.push({path:'/'})
//          this.posts = response.data
                    })

                alert(this.checkedNames);



            },

            submitCategory(){
                alert(this.checkedNames);
            }
        }

    }
</script>
