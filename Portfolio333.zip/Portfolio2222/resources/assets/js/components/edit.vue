<template>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Update Post</div>

                    <div class="panel-body">

                    <form v-on:submit= "submitEditPost()" enctype="multipart/form-data">
                        <div class="form-group">
                           <input type="text" v-model="posts.title" placeholder="title" class="form-control">
                        </div>
                           <div class="form-group">
                            <textarea rows="5" cols="20" v-model="posts.description" placeholder="title" class="form-control"></textarea>
                          </div>


                   		<div class="form-group">

                   	          <select v-model="posts.student_id">
                   				    	<option v-for="student in students" v-bind:value="student.id" v-text="student.name"></option>
                   			</select>

                   	   </div>


                        <div id='example-3'>
                            <!--<div v-for="cat2 in postcategories">-->
                                <!--<input type="checkbox" checked>-->




                            <!--</div>-->


                            <!--<div v-for="v_post in posts">-->

                                <!--<input v-if="v_post.category_id !=null" type="checkbox" checked="checked">-->
                                <!--<label for="jack">{{v_post.cat_name}}</label>-->

                                <!--<input  else type="checkbox">-->
                                <!--<label for="jack">{{v_post.cat_name}}</label>-->

                            <!--</div>-->

                            <div v-for="cat in categories">


                                <input type="checkbox" v-if="posts.category_id !=null" checked="checked">
                                <label for="jack">{{cat.cat_name}}</label>

                                <!--<input v-else type="checkbox">-->
                                <!--<label for="jack">{{cat.cat_name}}</label>-->


                            </div>


                            <!--<input type="checkbox" id="jack" value="1" v-model="checkedNames">-->
                            <!--<label for="jack">Jack</label>-->
                            <!--<input type="checkbox" id="john" value="2" v-model="checkedNames">-->
                            <!--<label for="john">John</label>-->
                            <!--<input type="checkbox" id="mike" value="3" v-model="checkedNames">-->
                            <!--<label for="mike">Mike</label>-->
                            <!--<br>-->
                            <span>Checked names: {{ checkedNames }}</span>




                        </div>


                            <div class="form-group">
                            <router-link to="/" class="btn btn-warning">Go to Back</router-link>
                              <button class="btn btn-info">Update</button>
                            </div>


                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import axios from 'axios';
    export default {
        data:function() {
           return {
             posts:{title:'',description:'',student_id:'',status:'',image:''},
               checkedNames: [],
               students:[],
               categories:[],
               postcategories:[],
             errors: []
           }
         },


         // Fetches posts when the component is created.

               created() {
                  this.fetchStudent();
                   this.fetchCategory();
                 let id=this.$route.params.eid;
                   axios.get('http://localhost/Portfolio2222/public/posts/'+id+'/edit')

                   .then(response => {
                       console.log(response)
                       //console.log(this.postcategories)
                     this.posts = response.data
                     //this.postcategories = response.data
                   })
                   .catch(e => {
                     this.errors.push(e)
                   })

                  },

     methods:{
         fetchStudent(){
          axios.get('http://localhost/Portfolio2222/public/stu').then(response=>{this.students=response.data.students});
          	},

         fetchCategory(){
             axios.get('http://localhost/Portfolio2222/public/cat').then(response=>{this.categories=response.data.categories});
         },
      submitEditPost() {
        let id=this.$route.params.eid;
        axios.patch('http://localhost/Portfolio2222/public/posts/'+id, this.posts)
        .then(response => {
          console.log(response)
          this.$router.push({path:'/'})
          this.posts = response.data
        })
        .catch(e => {
          this.errors.push(e)
        })

       }
      }

    }
</script>
