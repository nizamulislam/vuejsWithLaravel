<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Student;

class Post extends Model
{
    protected $fillable = ['title','description','student_id','status','image'];
    public function mystudent(){
        return $this->belongsTo(Student::class,'student_id');
    }

}
