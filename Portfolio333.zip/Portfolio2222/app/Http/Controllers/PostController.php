<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Post;
use App\Item;
use App\ItemProduct;
use DB;
use App\CategoryPost;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function homePage(){
        return view('homepage');
    }
    public function index()
    {
//        $post=Post::with('mystudent')->get();
//        return response()->json($post);
        $post=DB::table('posts')
              ->leftJoin('students','students.id','=','posts.student_id')
              ->select('posts.*','students.name')
              ->get();
        return response()->json($post);
    }


//        $x=json_decode($cate, true);
//        $y=implode(",",$x);
//
//
//        $item=new ItemProduct();
//        $item->name=$y;
//        $item->post_id=$post->id;
//        $item->save();


//
//       return response()->json($post);

 public function createPost(Request $request){
     $alldata=$request->all();
     if(count($alldata)>0){
         $postData=$alldata['posts'];
         $post=new Post();
         $post->title=$postData['title'];
         $post->description=$postData['description'];
         $post->student_id=$postData['student_id'];
         $post->save();

         if($post->id > 0){
             foreach ($alldata['checkedNames'] as $row)
             {
                 $charges = [

                     'category_id' => $row,
                     'post_id'=>$post->id,

                 ];

                 CategoryPost::insert($charges);
             }



         }





     }


//       $alldata=$request->all();
//
//
//     print_r($alldata['posts']);
//
//     foreach ($request->checkedNames as $row)
//     {
//         $charges[] = [
//
//             'category_name' => $row,
//             'post_id'=>$post->id,
//
//         ];
//     }
//
//     CategoryPost::insert($charges);







 }
//  public function store(Request $request){
////        $post=new Post();
////        $post->title=$request->title;
////        $post->description=$request->description;
////        $post->student_id=$request->student_id;
////        $post->save();
//
//      $x=$request->checkedNames;
//      var_dump($x);
//
//
//  }



    public function createItem2(Request $request){
        $x=$request->checkedNames;
        return response()->json($x);
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
//        $post=Post::find($id);
//        return response()->json($post);

        $post=DB::table('posts')
            ->leftJoin('students','students.id','=','posts.student_id')
            ->select('posts.*','students.name')
            ->where('posts.id',$id)
            ->first();
        return response()->json($post);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //$post=Post::find($id);
//
//        $post = DB::table('posts')
//                ->join('category_posts', 'posts.id', '=', 'category_posts.post_id')
//                ->select('posts.*', 'category_posts.post_id', 'category_posts.category_id')
//                ->where('posts.id', $id)
//                ->first();
//        return response()->json($post);
//        return $post;





        $post=DB::table('category_posts')
                        ->leftJoin('categories','category_posts.category_id','=','categories.id')
                         ->select('categories.cat_name','category_posts.*')
                        ->where('category_posts.post_id',$id)
                        ->get();
        return response()->json($post);



//

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $posts=Post::find($id);
        $posts->update($request->all());
        return $posts;

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $post=Post::find($id);
        $post->delete();
        return response()->json($post);

    }


    public function allStudent(){
        $students=DB::table('students')->get();
        return response()->json(['students'=>$students]);
    }

    public function allCategory(){
        $categories=DB::table('categories')->get();
        return response()->json(['categories'=>$categories]);
    }


    public function allItem(){
        $items=Item::all();
        return response()->json(['items'=>$items]);
    }

    public function createItem(Request $request,$multi)
    {

       $x=json_decode($multi, true);
       $y=implode(",",$x);


        $item=new ItemProduct();
        $item->name=$y;
        $item->save();


       // $item=ItemProduct::where('id','=',1)->update(['name'=>])
        //checkedNames
//        $x=json_decode($multi, true);
//        $as=1;
//
//            foreach($x as $key=>$value){
//                DB::table('item_products')->where('id',[$key][$as])->update([
//                    'name'=>$value
//
//                ]);
//
//           }


    }



}
