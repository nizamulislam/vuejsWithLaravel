<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">

            <div class="col-md-8 col-md-offset-2">
           <h1>Crud Operation</h1>
       </div>

            <div id="app">


                <!-- route outlet -->
                <!-- component matched by the route will render here -->
                <router-view></router-view>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>