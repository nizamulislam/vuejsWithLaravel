<template>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Collect List Info</div>

                    <div class="panel-body">
                    <router-link to="/create" class="btn btn-primary">New Post</router-link>
                    <table class="table table-bordered">
                        <thead>
                          <tr>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Student By</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr v-for="post, index in posts">

                            <td>{{post.title}}</td>
                            <td>{{post.description}}</td>
                            <td>{{post.name}}</td>
                            <td>

                             <router-link :to="{name:'viewPost',params:{vid:post.id}}" class="btn btn-primary">View</router-link>
  <router-link :to="{name:'editPost',params:{eid:post.id}}" class="btn btn-info">Edit</router-link>

   <button class="btn btn-danger" v-on:click="submitDeletePost(post.id,index)">Delete</button>


                            </td>
                          </tr>

                          <tr>
                          TotalPost: {{posts.length}}
                          </tr>



                        </tbody>
                      </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
      export default {
          data() {
             return {
             posts:[],
             errors:[]
             }
           },


           // Fetches posts when the component is created.


        created() {
          axios.get('http://localhost/Portfolio2222/public/posts')
          .then(response => {
            this.posts = response.data
          })
          .catch(e => {
            this.errors.push(e)
          })

         },
           methods:{
               submitDeletePost(id,index) {

                 if(confirm("Click 'OK' to delete."))
                   {
                        axios.delete('http://localhost/Portfolio2222/public/posts/'+id)
                          .then(response => {
                          console.log(response)
                        this.posts.splice(index,1);
                          })
                         .catch(e => {
                         this.errors.push(e)
                         })
                   }

                }
               }


      }
</script>
