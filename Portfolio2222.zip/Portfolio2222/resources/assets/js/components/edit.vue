<template>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Update Post</div>

                    <div class="panel-body">

                    <form v-on:submit= "submitEditPost()" enctype="multipart/form-data">
                        <div class="form-group">
                           <input type="text" v-model="posts.title" placeholder="title" class="form-control">
                        </div>
                           <div class="form-group">
                            <textarea rows="5" cols="20" v-model="posts.description" placeholder="title" class="form-control"></textarea>
                          </div>


                   		<div class="form-group">

                   	          <select v-model="posts.student_id">
                   				    	<option v-for="student in students" v-bind:value="student.id" v-text="student.name"></option>
                   			</select>

                   	   </div>


                            <div class="form-group">
                            <router-link to="/" class="btn btn-warning">Go to Back</router-link>
                              <button class="btn btn-info">Update</button>
                            </div>


                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import axios from 'axios';
    export default {
        data:function() {
           return {
             posts:{title:'',description:'',student_id:'',status:'',image:''},
             students:[],
             errors: []
           }
         },


         // Fetches posts when the component is created.

               created() {
                  this.fetchStudent();
                 let id=this.$route.params.eid;
                   axios.get('http://localhost/Portfolio2222/public/posts/'+id+'/edit')
                   .then(response => {
                     this.posts = response.data
                   })
                   .catch(e => {
                     this.errors.push(e)
                   })

                  },

     methods:{
         fetchStudent(){
          axios.get('http://localhost/Portfolio2222/public/stu').then(response=>{this.students=response.data.students});
          	},
      submitEditPost() {
        let id=this.$route.params.eid;
        axios.patch('http://localhost/Portfolio2222/public/posts/'+id, this.posts)
        .then(response => {
          console.log(response)
          this.$router.push({path:'/'})
          this.posts = response.data
        })
        .catch(e => {
          this.errors.push(e)
        })

       }
      }

    }
</script>
