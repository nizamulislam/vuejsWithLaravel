@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">

            <div class="col-md-8 col-md-offset-2">
           <h1>Crud Operation</h1>
       </div>

            <div id="app">


                <!-- route outlet -->
                <!-- component matched by the route will render here -->
                <router-view></router-view>
            </div>

        </div>
    </div>
@endsection
