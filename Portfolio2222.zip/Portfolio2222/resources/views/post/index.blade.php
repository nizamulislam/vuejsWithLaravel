@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <router-link to="/foo">Go to Foo</router-link>
                        <router-link to="/bar">Go to Bar</router-link>
                    </div>

                    <div class="panel-body">
                       <table class="table table-bordered">
                           <tr>
                               <th>#</th>
                               <th>Title</th>
                               <th>Description</th>
                               <th>Action</th>
                           </tr>
                           <tr>
                               <td>1</td>
                               <td>Tt</td>
                               <td>sdsff</td>
                               <td>
                                   <a href="">Edit</a>
                               </td>

                           </tr>

                       </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
